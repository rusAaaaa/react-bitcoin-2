export default function App() {
  return <h1>React Crypto App</h1>
}
